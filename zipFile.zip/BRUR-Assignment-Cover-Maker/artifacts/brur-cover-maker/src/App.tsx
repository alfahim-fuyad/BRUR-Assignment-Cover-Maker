import { type ChangeEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronDown,
  Clipboard,
  Download,
  FileText,
  GraduationCap,
  LayoutTemplate,
  Plus,
  Printer,
  RotateCcw,
  Save,
  Search,
  Sparkles,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import logoPath from '@assets/BRUR_Logo_1789044011278.svg';

const queryClient = new QueryClient();

type Design = 'simple' | 'professional' | 'modern';
type AssignmentType = 'individual' | 'group';
type Teacher = { id: number; name: string; designation: string };
type Course = { code: string; title: string; department: string };
type FormState = {
  department: string;
  courseTitle: string;
  courseCode: string;
  teacher: Teacher;
  teacherName: string;
  teacherDesignation: string;
  topic: string;
  session: string;
  date: string;
  assignmentType: AssignmentType;
  studentName: string;
  studentId: string;
  batch: string;
  semester: string;
  groupMembers: string[];
  design: Design;
};

const teachers: Teacher[] = [
  { id: 50, name: 'Prof. Dr. Abu Kalam Md. Farid Ul Islam', designation: 'Professor' },
  { id: 45, name: 'Dr. Md. Mizanur Rahoman', designation: 'Professor' },
  { id: 194, name: 'Dr. Ileas Pramanik', designation: 'Professor' },
  { id: 195, name: 'Dr. Prodip Kumar Sarker', designation: 'Associate Professor' },
  { id: 196, name: 'Md. Zasim Uddin', designation: 'Associate Professor' },
  { id: 197, name: 'Md. Shamsuzzaman', designation: 'Assistant Professor' },
  { id: 198, name: 'Md. Abul Kalam Azad (On Study Leave)', designation: 'Assistant Professor' },
  { id: 200, name: 'Sanjoy Kumar Saha (On Study Leave)', designation: 'Assistant Professor' },
  { id: 201, name: 'Marjia Sultana', designation: 'Assistant Professor' },
  { id: 202, name: 'Md. Hasan Tarek', designation: 'Lecturer' },
  { id: 434, name: 'Md. Faruk Hosen', designation: 'Lecturer' },
];

const courses: Course[] = [
  { code: 'CSE 1101', title: 'Introduction to Computer Science', department: 'CSE' },
  { code: 'CSE 1203', title: 'Structured Programming', department: 'CSE' },
  { code: 'CSE 2205', title: 'Data Structures', department: 'CSE' },
  { code: 'CSE 3107', title: 'Database Management Systems', department: 'CSE' },
  { code: 'CSE 4101', title: 'Software Engineering', department: 'CSE' },
  { code: 'EEE 2103', title: 'Electrical Circuits and Measurements', department: 'EEE' },
];

const today = new Date().toISOString().slice(0, 10);
const firstTeacher = teachers[0];
const initialState: FormState = {
  department: 'CSE',
  courseTitle: courses[0].title,
  courseCode: courses[0].code,
  teacher: firstTeacher,
  teacherName: firstTeacher.name,
  teacherDesignation: firstTeacher.designation,
  topic: 'A thoughtful title for your assignment',
  session: '2024–2025',
  date: today,
  assignmentType: 'individual',
  studentName: 'Your name',
  studentId: '',
  batch: '12th',
  semester: 'Spring',
  groupMembers: [],
  design: 'professional',
};

function readSaved(): FormState | null {
  try {
    const saved = localStorage.getItem('brur-cover-draft');
    return saved ? (JSON.parse(saved) as FormState) : null;
  } catch {
    return null;
  }
}

function AppShell({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

function CoverPreview({ form }: { form: FormState }) {
  const members = form.assignmentType === 'group' ? form.groupMembers.filter(Boolean) : [];
  const shared = (
    <>
      <img className="mx-auto h-20 w-20 object-contain sm:h-24 sm:w-24" src={logoPath} alt="BRUR crest" data-testid="img-preview-logo" />
      <p className="mt-5 text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-500">Begum Rokeya University</p>
      <p className="mt-1 text-[10px] tracking-[0.12em] text-slate-400">Rangpur, Bangladesh</p>
    </>
  );
  const details = (
    <div className="mt-12 space-y-5 text-left">
      <div>
        <p className="preview-label">Assignment topic</p>
        <p className="mt-1 text-lg font-semibold leading-tight text-slate-900" data-testid="text-preview-topic">{form.topic || 'Untitled assignment'}</p>
      </div>
      <div className="grid grid-cols-2 gap-4 border-y border-slate-200 py-4">
        <div><p className="preview-label">Course</p><p className="mt-1 font-semibold text-slate-800">{form.courseTitle || 'Course title'}</p><p className="text-xs text-slate-500">{form.courseCode || 'Course code'}</p></div>
        <div><p className="preview-label">Session</p><p className="mt-1 font-semibold text-slate-800">{form.session || 'Academic session'}</p></div>
      </div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
        <div><p className="preview-label">Submitted by</p><p className="mt-1 font-medium text-slate-800">{form.studentName || 'Student name'}</p><p className="text-xs text-slate-500">{form.studentId || 'ID number'}</p></div>
        <div><p className="preview-label">Batch / semester</p><p className="mt-1 font-medium text-slate-800">{form.batch || '—'} · {form.semester || '—'}</p></div>
      </div>
      {members.length > 0 && <div><p className="preview-label">Group members</p><p className="mt-1 text-sm leading-6 text-slate-700">{members.join(' · ')}</p></div>}
      <div className="border-t border-slate-200 pt-4"><p className="preview-label">Submitted to</p><p className="mt-1 font-semibold text-slate-800">{form.teacherName || 'Teacher name'}</p><p className="text-xs text-slate-500">{form.teacherDesignation || 'Designation'} · Department of {form.department}</p></div>
    </div>
  );

  if (form.design === 'simple') return <div className="cover-paper simple-cover p-8 text-center sm:p-12">{shared}{details}<p className="mt-12 text-[10px] text-slate-400">{form.date || today}</p></div>;
  if (form.design === 'modern') return (
    <div className="cover-paper modern-cover overflow-hidden p-7 sm:p-10">
      <div className="modern-mark" />
      <div className="relative text-center">{shared}</div>
      <div className="relative mt-12 border-l-4 border-[#e56b51] pl-5">{details}</div>
      <p className="relative mt-10 text-right text-[10px] font-medium uppercase tracking-[0.16em] text-slate-400">{form.date || today}</p>
    </div>
  );
  return (
    <div className="cover-paper professional-cover p-8 text-center sm:p-12">
      <div className="mx-auto max-w-[92%] border border-[#1a8d7f]/30 px-5 py-7 sm:px-8 sm:py-9">{shared}{details}<div className="mt-10 flex justify-between border-t border-slate-200 pt-4 text-left text-[10px] uppercase tracking-[0.13em] text-slate-400"><span>Department of {form.department}</span><span>{form.date || today}</span></div></div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = 'text', testId, className = '' }: { label: string; value: string; onChange: (event: ChangeEvent<HTMLInputElement>) => void; placeholder?: string; type?: string; testId: string; className?: string }) {
  return <label className={className}><span className="field-label">{label}</span><input className="input-shell" type={type} value={value} onChange={onChange} placeholder={placeholder} data-testid={testId} /></label>;
}

function SectionTitle({ number, icon, title, note }: { number: string; icon: ReactNode; title: string; note: string }) {
  return <div className="mb-5 flex items-start gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700">{icon}</div><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-teal-700">Step {number}</p><h2 className="font-display text-lg font-bold text-slate-900">{title}</h2><p className="mt-0.5 text-xs text-slate-500">{note}</p></div></div>;
}

function Home() {
  const [form, setForm] = useState<FormState>(() => readSaved() ?? initialState);
  const [teacherQuery, setTeacherQuery] = useState('');
  const [saved, setSaved] = useState(Boolean(readSaved()));
  const [saveLabel, setSaveLabel] = useState('Save draft');
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    document.title = 'BRUR Cover Maker · Assignment workspace';
  }, []);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));
  const filteredTeachers = useMemo(() => teachers.filter((teacher) => teacher.name.toLowerCase().includes(teacherQuery.toLowerCase()) || String(teacher.id).includes(teacherQuery)), [teacherQuery]);
  const departmentCourses = courses.filter((course) => course.department === form.department);

  const chooseDepartment = (department: string) => {
    const nextCourse = courses.find((course) => course.department === department) ?? courses[0];
    setForm((current) => ({ ...current, department, courseTitle: nextCourse.title, courseCode: nextCourse.code }));
  };
  const chooseCourse = (title: string) => {
    const course = courses.find((item) => item.title === title);
    setForm((current) => ({ ...current, courseTitle: title, courseCode: course?.code ?? '' }));
  };
  const chooseTeacher = (teacher: Teacher) => {
    setForm((current) => ({ ...current, teacher, teacherName: teacher.name, teacherDesignation: teacher.designation }));
    setTeacherQuery('');
  };
  const saveDraft = () => {
    localStorage.setItem('brur-cover-draft', JSON.stringify(form));
    setSaved(true);
    setSaveLabel('Draft saved');
    setNotice('Your cover is saved on this device.');
    window.setTimeout(() => setSaveLabel('Save draft'), 1800);
  };
  const copyPrevious = () => {
    const previous = readSaved();
    if (!previous) {
      setNotice('Save a draft first and it will be available here next time.');
      return;
    }
    setForm({ ...previous, topic: `${previous.topic} — copy`, date: today });
    setNotice('Previous assignment copied into the workspace.');
  };
  const updateMember = (index: number, value: string) => setForm((current) => ({ ...current, groupMembers: current.groupMembers.map((member, memberIndex) => memberIndex === index ? value : member) }));
  const addMember = () => setForm((current) => ({ ...current, groupMembers: [...current.groupMembers, ''] }));
  const removeMember = (index: number) => setForm((current) => ({ ...current, groupMembers: current.groupMembers.filter((_, memberIndex) => memberIndex !== index) }));
  const download = (kind: 'html' | 'txt') => {
    const title = form.topic || 'BRUR-assignment-cover';
    const cleanTitle = title.replace(/[^a-z0-9]+/gi, '-').toLowerCase();
    const body = kind === 'html' ? coverHtml(form) : coverText(form);
    const blob = new Blob([body], { type: kind === 'html' ? 'text/html' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${cleanTitle || 'brur-cover'}.${kind === 'html' ? 'html' : 'txt'}`;
    link.click();
    URL.revokeObjectURL(url);
    setDownloadOpen(false);
    setNotice(`${kind.toUpperCase()} cover downloaded.`);
  };
  const field = (key: keyof FormState) => (event: ChangeEvent<HTMLInputElement>) => update(key, event.target.value as never);

  return (
    <div className="mesh-bg min-h-[100dvh]">
      <header className="no-print border-b border-slate-200/80 bg-[#f4f8f8]/90 backdrop-blur">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between px-4 py-4 sm:px-7 lg:px-10">
          <div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white p-1.5 shadow-sm"><img src={logoPath} alt="Begum Rokeya University logo" className="h-full w-full object-contain" data-testid="img-brand-logo" /></div><div><p className="font-display text-[15px] font-bold tracking-tight text-[#164a5b]">BRUR Cover Maker</p><p className="hidden text-[11px] text-slate-500 sm:block">Academic stationery, made simple.</p></div></div>
          <div className="flex items-center gap-2 text-xs font-medium text-slate-500"><span className="hidden items-center gap-1.5 rounded-full bg-white px-3 py-1.5 shadow-sm sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#1a9b86]" /> Saved locally</span><button className="rounded-xl p-2 text-slate-400 transition hover:bg-white hover:text-slate-700" onClick={copyPrevious} aria-label="Copy previous assignment" data-testid="button-copy-header"><RotateCcw size={17} /></button></div>
        </div>
      </header>
      <main className="mx-auto max-w-[1500px] px-4 pb-16 pt-7 sm:px-7 sm:pt-10 lg:px-10">
        <div className="no-print mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end"><div className="max-w-2xl rise-in"><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-teal-100 bg-teal-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.13em] text-teal-700"><Sparkles size={13} /> A polished start to every submission</div><h1 className="font-display text-3xl font-bold tracking-[-0.045em] text-[#164a5b] sm:text-4xl lg:text-[46px]">Build a cover page<br /><span className="text-[#1a9b86]">worth submitting.</span></h1><p className="mt-3 max-w-xl text-sm leading-6 text-slate-500">Fill in the essentials, choose a style, and preview your BRUR assignment cover as you go. No account, no upload, no fuss.</p></div><div className="no-print flex gap-2"><button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-bold text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:border-teal-200" onClick={copyPrevious} data-testid="button-copy-previous"><Clipboard size={15} /> Copy previous</button><div className="relative"><button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-bold text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:border-teal-200" onClick={() => setDownloadOpen(!downloadOpen)} data-testid="button-download"><Download size={15} /> Download <ChevronDown size={14} /></button>{downloadOpen && <div className="absolute right-0 z-20 mt-2 w-44 overflow-hidden rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl"><button className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold hover:bg-teal-50" onClick={() => download('html')} data-testid="button-download-html"><FileText size={14} /> HTML document</button><button className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold hover:bg-teal-50" onClick={() => download('txt')} data-testid="button-download-text"><FileText size={14} /> Text document</button></div>}</div><button className="inline-flex items-center gap-2 rounded-xl bg-[#164a5b] px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-[#164a5b]/15 transition hover:-translate-y-0.5 hover:bg-[#1d6074]" onClick={() => window.print()} data-testid="button-print"><Printer size={15} /> Print</button></div></div>
        {notice && <div className="no-print mb-5 flex items-center justify-between rounded-xl border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-semibold text-teal-800 soft-pop" data-testid="status-notice"><span className="flex items-center gap-2"><Check size={15} /> {notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss notice" data-testid="button-dismiss-notice"><X size={15} /></button></div>}
        <div className="grid items-start gap-7 lg:grid-cols-[minmax(0,1fr)_minmax(420px,0.82fr)] xl:gap-10">
          <div className="no-print space-y-5">
            <section className="section-card rise-in" style={{ animationDelay: '.05s' }}><SectionTitle number="01" icon={<GraduationCap size={17} />} title="Course & department" note="Start with the class this work belongs to." /><div className="grid gap-4 sm:grid-cols-2"><label><span className="field-label">Department</span><div className="relative"><select className="select-shell pr-9" value={form.department} onChange={(event) => chooseDepartment(event.target.value)} data-testid="select-department">{['CSE', 'EEE', 'ICE', 'Mathematics'].map((department) => <option key={department} value={department}>{department} · Department</option>)}</select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-slate-400" size={15} /></div></label><label><span className="field-label">Course</span><div className="relative"><select className="select-shell pr-9" value={form.courseTitle} onChange={(event) => chooseCourse(event.target.value)} data-testid="select-course">{departmentCourses.length ? departmentCourses.map((course) => <option key={course.code} value={course.title}>{course.title}</option>) : <option value="">Choose a course</option>}</select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-slate-400" size={15} /></div></label></div><div className="mt-4 rounded-xl bg-[#eaf5f3] px-4 py-3"><span className="text-[10px] font-bold uppercase tracking-[0.15em] text-teal-700">Course code</span><p className="mt-0.5 font-mono text-sm font-semibold text-[#164a5b]" data-testid="text-course-code">{form.courseCode || 'Selected course code will appear here'}</p></div></section>
            <section className="section-card rise-in" style={{ animationDelay: '.1s' }}><SectionTitle number="02" icon={<UserRound size={17} />} title="Teacher" note="Search the CSE faculty list or refine the details below." /><div className="relative"><span className="field-label">Search faculty</span><Search className="absolute left-3.5 top-10 text-slate-400" size={16} /><input className="input-shell pl-10" value={teacherQuery} onChange={(event) => setTeacherQuery(event.target.value)} placeholder="Search by name or faculty ID" data-testid="input-teacher-search" />{teacherQuery && <div className="absolute z-10 mt-1 max-h-56 w-full overflow-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl">{filteredTeachers.length ? filteredTeachers.map((teacher) => <button key={teacher.id} className="flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left hover:bg-teal-50" onClick={() => chooseTeacher(teacher)} data-testid={`button-teacher-${teacher.id}`}><span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-[10px] font-bold text-slate-500">{teacher.id}</span><span><span className="block text-sm font-semibold text-slate-800">{teacher.name}</span><span className="block text-xs text-slate-500">{teacher.designation}</span></span></button>) : <p className="px-3 py-3 text-xs text-slate-500">No faculty match.</p>}</div>}</div><div className="mt-4 rounded-xl border border-teal-100 bg-teal-50/50 px-3.5 py-3"><p className="text-[10px] font-bold uppercase tracking-[0.13em] text-teal-700">Selected faculty · ID {form.teacher.id}</p><p className="mt-1 text-sm font-semibold text-[#164a5b]">{form.teacherName}</p></div><div className="mt-4 grid gap-4 sm:grid-cols-2"><Field label="Teacher name" value={form.teacherName} onChange={field('teacherName')} testId="input-teacher-name" /><Field label="Designation" value={form.teacherDesignation} onChange={field('teacherDesignation')} testId="input-teacher-designation" /></div></section>
            <section className="section-card rise-in" style={{ animationDelay: '.15s' }}><SectionTitle number="03" icon={<BookOpen size={17} />} title="Assignment details" note="A clear topic makes a confident first impression." /><Field label="Assignment topic" value={form.topic} onChange={field('topic')} placeholder="e.g. A comparative study of sorting algorithms" testId="input-topic" /><div className="mt-4 grid gap-4 sm:grid-cols-3"><Field label="Academic session" value={form.session} onChange={field('session')} testId="input-session" /><Field label="Submission date" type="date" value={form.date} onChange={field('date')} testId="input-date" /><label><span className="field-label">Course code</span><input className="input-shell bg-slate-100 text-slate-500" value={form.courseCode} readOnly data-testid="input-course-code" /></label></div></section>
            <section className="section-card rise-in" style={{ animationDelay: '.2s' }}><SectionTitle number="04" icon={<Users size={17} />} title="Student information" note="Choose individual or group submission." /><div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1"><button className={`flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-xs font-bold transition ${form.assignmentType === 'individual' ? 'bg-white text-[#164a5b] shadow-sm' : 'text-slate-500'}`} onClick={() => update('assignmentType', 'individual')} data-testid="button-individual"><UserRound size={15} /> Individual</button><button className={`flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-xs font-bold transition ${form.assignmentType === 'group' ? 'bg-white text-[#164a5b] shadow-sm' : 'text-slate-500'}`} onClick={() => update('assignmentType', 'group')} data-testid="button-group"><Users size={15} /> Group</button></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Student name" value={form.studentName} onChange={field('studentName')} testId="input-student-name" /><Field label="Student ID" value={form.studentId} onChange={field('studentId')} placeholder="e.g. 2024331012" testId="input-student-id" /><Field label="Batch" value={form.batch} onChange={field('batch')} testId="input-batch" /><label><span className="field-label">Semester</span><div className="relative"><select className="select-shell pr-9" value={form.semester} onChange={(event) => update('semester', event.target.value)} data-testid="select-semester"><option>Spring</option><option>Summer</option><option>Fall</option></select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-slate-400" size={15} /></div></label></div>{form.assignmentType === 'group' && <div className="mt-5 border-t border-slate-100 pt-4"><div className="mb-3 flex items-center justify-between"><span className="field-label mb-0">Group members</span><button className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-900" onClick={addMember} data-testid="button-add-member"><Plus size={14} /> Add member</button></div><div className="space-y-2">{form.groupMembers.map((member, index) => <div className="flex gap-2" key={`member-${index}`}><input className="input-shell" value={member} onChange={(event) => updateMember(index, event.target.value)} placeholder={`Member ${index + 1} name`} data-testid={`input-member-${index}`} /><button className="rounded-xl px-2.5 text-slate-400 hover:bg-red-50 hover:text-red-500" onClick={() => removeMember(index)} aria-label={`Remove member ${index + 1}`} data-testid={`button-remove-member-${index}`}><Trash2 size={16} /></button></div>)}</div>{!form.groupMembers.length && <p className="rounded-lg bg-slate-50 px-3 py-2.5 text-xs text-slate-500">Add classmates to list them on the cover.</p>}</div>}</section>
            <section className="section-card rise-in" style={{ animationDelay: '.25s' }}><SectionTitle number="05" icon={<LayoutTemplate size={17} />} title="Choose a finish" note="Each template is built for clean A4 printing." /><div className="grid gap-3 sm:grid-cols-3">{(['simple', 'professional', 'modern'] as Design[]).map((design) => <button key={design} onClick={() => update('design', design)} className={`template-option ${form.design === design ? 'template-option-active' : ''}`} data-testid={`button-template-${design}`}><div className={`template-mini mini-${design}`}><span /><span /><span /></div><span className="mt-2 block text-xs font-bold capitalize text-slate-700">{design}</span><span className="mt-0.5 block text-[10px] text-slate-400">{design === 'simple' ? 'Quiet and classic' : design === 'modern' ? 'Fresh and expressive' : 'Structured and formal'}</span>{form.design === design && <Check className="absolute right-2 top-2 text-teal-600" size={15} />}</button>)}</div></section>
            <div className="no-print flex items-center justify-between rounded-2xl border border-[#c7e9e2] bg-[#effaf7] p-4"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-teal-600 shadow-sm"><Save size={16} /></div><div><p className="text-xs font-bold text-[#164a5b]">Keep your progress</p><p className="text-[11px] text-slate-500">Drafts stay in this browser only.</p></div></div><button className="rounded-xl bg-[#1a8d7f] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#147666]" onClick={saveDraft} data-testid="button-save-draft">{saved && saveLabel === 'Save draft' ? 'Save again' : saveLabel}</button></div>
          </div>
          <aside className="lg:sticky lg:top-6"><div className="no-print mb-3 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-teal-700">Live preview</p><h2 className="font-display text-lg font-bold text-[#164a5b]">Your cover, in focus.</h2></div><div className="rounded-full bg-white px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.13em] text-slate-400 shadow-sm">A4 · {form.design}</div></div><div className="preview-frame soft-pop" data-testid="section-preview"><CoverPreview form={form} /></div><div className="no-print mt-4 flex items-center gap-2 rounded-xl border border-slate-200 bg-white/75 px-3.5 py-3 text-xs text-slate-500"><Sparkles size={14} className="shrink-0 text-[#e56b51]" /><span>Updates as you type. Print when the details feel right.</span><ArrowRight size={14} className="ml-auto shrink-0 text-slate-300" /></div></aside>
        </div>
      </main>
      <footer className="no-print border-t border-slate-200/70 bg-white/50 px-4 py-6 text-center text-[11px] text-slate-400"><p>Made for BRUR students · Your information never leaves this browser.</p></footer>
    </div>
  );
}

function coverText(form: FormState) {
  const members = form.groupMembers.filter(Boolean);
  return `BEGUM ROKEYA UNIVERSITY\nRANGPUR, BANGLADESH\n\nASSIGNMENT COVER\n\nTopic: ${form.topic || 'Untitled assignment'}\nCourse: ${form.courseTitle} (${form.courseCode})\nSession: ${form.session}\n\nSubmitted by:\n${form.studentName}\nID: ${form.studentId || '—'}\nBatch: ${form.batch} | Semester: ${form.semester}\n${members.length ? `Group members: ${members.join(', ')}\n` : ''}\nSubmitted to:\n${form.teacherName}\n${form.teacherDesignation}\nDepartment of ${form.department}\n\nSubmission date: ${form.date}`;
}

function coverHtml(form: FormState) {
  const escape = (value: string) => value.replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char] ?? char);
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escape(form.topic || 'BRUR assignment cover')}</title><style>body{font-family:Georgia,serif;color:#173d4d;padding:72px;text-align:center}img{width:100px}.cover{max-width:680px;margin:auto;border:1px solid #8bc7bc;padding:54px}h1{font-size:23px;font-weight:500;letter-spacing:3px}h2{font-size:25px;margin:60px 0 12px}p{line-height:1.7}.details{text-align:left;border-top:1px solid #dce7e5;padding-top:24px;margin-top:40px}</style></head><body><div class="cover"><img src="${logoPath}" alt="BRUR logo"><p>BEGUM ROKEYA UNIVERSITY<br>RANGPUR, BANGLADESH</p><h1>ASSIGNMENT</h1><h2>${escape(form.topic || 'Untitled assignment')}</h2><div class="details"><p><b>Course</b><br>${escape(form.courseTitle)} · ${escape(form.courseCode)}</p><p><b>Submitted by</b><br>${escape(form.studentName)} · ${escape(form.studentId || 'ID number')}<br>${escape(form.batch)} · ${escape(form.semester)}</p><p><b>Submitted to</b><br>${escape(form.teacherName)}<br>${escape(form.teacherDesignation)}, Department of ${escape(form.department)}</p><p><b>Date:</b> ${escape(form.date)}</p></div></div></body></html>`;
}

function Router() {
  return <AppShell><ErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></ErrorBoundary></AppShell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;